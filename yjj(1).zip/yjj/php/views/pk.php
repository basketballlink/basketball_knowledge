<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pk</title>
</head>
<body>
    <h1>pk</h1>
    <a href="pk/th/5">aaa</a>
    <?php
     require_once './functions.php';
    ?>
    <?php
     dd(parse_url($_SERVER["REQUEST_URI"]));
    ?>
    <a href="pk/"></a>
</body>
</html>