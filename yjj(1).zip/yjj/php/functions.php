<?php
function queryPosts(){
    $servername = "localhost";
    $username = "root";
    $password = "aB20150829";
    
    $conn = new PDO("mysql:host=$servername;", $username, $password);

    $statement = $conn->query('select * from bas.celtics;');

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

function dd($data){
    echo '<pre>';
    var_dump($data);
    echo '<pre>';
}
?>
<?php
  class Router{

    public $getRoutes = [];
    public function get ($url,$fn){
        $this->getRoutes[$url] = $fn;
    }
    public function handle(){
        $current = $_SERVER["REQUEST_URI"];
        $path = parse_url($current)['path'];
        // echo $current;
        // echo $path;
        // echo $_SERVER["REQUEST_METHOD"];
        if($_SERVER["REQUEST_METHOD"] == 'GET'){
            $fn = $this->getRoutes[$path];
        }
        $controller = new $fn[0];
        call_user_func([$controller, $fn[1]]);
    }
  }
  
?>
<?php

class Post{
    public $id;
    public $name;
    public $birth;
    public $introduction;

    public static function find($id){
      $servername = "localhost";
      $username = "root";
      $password = "aB20150829";
      
      $conn = new PDO("mysql:host=$servername;", $username, $password);

      $sql = 'select * from bas.celtics where id = :id;';

      $statement = $conn->prepare($sql);
      $statement->execute((['id'=> $id]));

      return $statement->fetchObject('Post');
      }
}
?>
<?php 
   class PageController{

     public function pre_team()
     {
        require_once 'views/pre_team.php';
     }
     public function teams(){
        require_once 'views/teams.php';
     }
     public function show(){
      $id = $_REQUEST['id'];
      
      $team = Post::find($id);
      
      require_once 'views/team-show.php';
     }
     public function pk(){

      require_once 'views/pk.php';
     }
   }
?>
<?php


?>