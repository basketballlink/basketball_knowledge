
<?php
    require_once 'functions.php';

    $router = new Router();

    $router->get('/',[PageController::class,'pre_team']);
    $router->get('/teams',[PageController::class,'teams']);
    $router->get('/team',[PageController::class,'show']);
    $router->get('/pk',[PageController::class,'pk']);

    $router->handle();


?>

