<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./player_pk.css">
    <title>球员PK</title>
    <script src="echarts.min.js"></script>
    
</head>
<body class="clearfix">
    <div class='nav'>
        <ul>
            <li><a href="#">篮球百科</a></li>
            <li><a href="#">NBA</a></li>
            <li><a href="#">CBA</a></li>
            <li><a href="#">球员PK</a></li>
        </ul>
    </div>
    <div class="header">
    <div class="player_left">
        <img src="images/zhanmusi.png" >
        <div class="inf">
        <span class="name">詹姆斯</span>
        <span class="name_en">LeBron James</span>
        <span class="info">湖人 前锋 6号</span>
        <div class="change"></div>
        </div>
    </div>
    <div class="player_right">
        <img src="images/ouwen.png" >
        <div class="inf">
        <span class="name">欧文</span>
        <span class="name_en"> Kyrie Irving</span>
        <span class="info">独行侠 后卫 2号</span>
        <div class="change"></div>
        </div>
    </div>

    <div id="r_h" style="height: 500px; width: 50%"; class="radar_h"></div>
    <div id="r_a" style="height: 500px; width: 50%"; class="radar_a"></div>
    </div>
    
    <script>
        var chartDom = document.getElementById('r_h');
        var myChart = echarts.init(chartDom);
        var option;

        option = {
        title: {
            text: '生涯最高数据对比'
        },
        legend: {
            data: ['詹姆斯', '欧文']
        },
        radar: {
            // shape: 'circle',
            indicator: [
            { name: '得分', max: 100 },
            { name: '篮板', max: 35 },
            { name: '助攻', max: 30 },
            { name: '抢断', max: 11 },
            { name: '盖帽', max: 17 }
            ]
        },
        series: [
            {
            name: 'Budget vs spending',
            type: 'radar',
            data: [
                {
                value: [61, 19, 19, 7, 5],
                name: '詹姆斯'
                },
                {
                value: [60, 11, 18, 6, 4],
                name: '欧文'
                }
            ]
            }
        ]
        };

        option && myChart.setOption(option);
    </script>
    <script>
        var chartDom = document.getElementById('r_a');
        var myChart = echarts.init(chartDom);
        var option;

        option = {
        title: {
            text: '生涯平均数据对比'
        },
        legend: {
            data: ['詹姆斯', '欧文']
        },
        radar: {
            // shape: 'circle',
            indicator: [
            { name: '得分', max: 35 },
            { name: '篮板', max: 12 },
            { name: '助攻', max: 12 },
            { name: '抢断', max: 3 },
            { name: '盖帽', max: 3 }
            ]
        },
        series: [
            {
            name: 'Budget vs spending',
            type: 'radar',
            data: [
                {
                value: [27.2, 7.5, 7.3, 1.5, 0.8],
                name: '詹姆斯'
                },
                {
                value: [23.3, 3.9, 5.7, 1.3, 0.4],
                name: '欧文'
                }
            ]
            }
        ]
        };

        option && myChart.setOption(option);

    </script>
</body>
</html>