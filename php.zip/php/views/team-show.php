<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>team-shoe</title>
</head>
<body>
    
<?php
  require_once './functions.php'
?>
<main class="container">
    <h1><?= $team->id ?></h1>
    <h1><?= $team->name ?></h1>
    <article><?= $team->introduction ?></article>
</main>

</body>
</html>